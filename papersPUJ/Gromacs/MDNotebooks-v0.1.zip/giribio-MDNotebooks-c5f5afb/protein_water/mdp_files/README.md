MDP files are parameter files used to parameterise each step in the Gromacs MD Simulation.

### Note: Kindly remove the following prefix from the filenames to directly use them in the Jupyter Notebooks

files prefixed with mdtut_ is from Tutorial 1

files prefixed with adk_is from Tutorial 2
