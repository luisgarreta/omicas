Molecular Dynamics made easy with Jupyter Notebook.



Tutorials are taken from

1. Justin A. Lemkul, Ph.D. Virginia Tech Department of Biochemistry - http://www.mdtutorials.com/gmx/index.html, and

2. https://adkgromacstutorial.readthedocs.io/en/latest/

#### Install anaconda from the web - https://www.anaconda.com/products/individual
#### Install Gromacs from the web or run - conda install -c bioconda gromacs
#### Install libraries - conda install nglview mdanalysis
#### Install additional libraries -  pip install GromacsWrapper pytraj
